//
//  Utah.swift
//  OpenSkyUtah
//
//  Created by Stephen Liddle on 11/14/23.
//

import Foundation

struct Utah {
    static let latitudeMax = 42.0
    static let latitudeMin = 37.0
    static let longitudeMax = -109.0
    static let longitudeMin = -114.0
}
