//
//  TitleViewModel.swift
//  TestRecipe
//
//  Created by Tanner Glazier on 12/13/23.
//

import Foundation

class TitleViewModel: ObservableObject {
    @Published var titles: [Title] = []  // Published array of titles

    // Instance of TitleStorage to manage saving and loading
    private var titleStorage = TitleStorage()

    // Constructor - loads titles from storage
    init() {
        loadTitles()
    }

    // Load titles from storage
    func loadTitles() {
        titles = titleStorage.getTitles()
    }

    // Save a given title
    func saveTitle(_ title: Title) {
        // Check if the title already exists and update it
        if let index = titles.firstIndex(where: { $0.id == title.id }) {
            titles[index] = title
        } else {
            titles.append(title)  // If new, append to the list
        }
        titleStorage.saveTitles(titles)
    }

    // Get a title by its ID
    func getTitleById(_ id: UUID) -> Title {
        titles.first { $0.id == id } ?? Title(titleText: "")
    }
}
