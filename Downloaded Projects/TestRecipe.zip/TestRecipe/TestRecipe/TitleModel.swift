//
//  TitleModel.swift
//  TestRecipe
//
//  Created by Tanner Glazier on 12/13/23.
import Foundation

struct Title: Codable, Identifiable {
    var id = UUID()           // Unique identifier for each title
    var titleText: String     // Text of the title
}

class TitleStorage {
    private var titles: [Title] = []  // Array to store titles
    private let fileURL: URL          // URL for the file to store data

    // Constructor - initializes file URL and loads titles
    init() {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        fileURL = documentsDirectory.appendingPathComponent("titles.json")
        loadTitles()
    }

    // Load titles from local file
    func loadTitles() {
        do {
            let data = try Data(contentsOf: fileURL)
            titles = try JSONDecoder().decode([Title].self, from: data)
        } catch {
            print("Error loading titles: \(error)")
            titles = []
        }
    }

    // Save titles to local file
    func saveTitles(_ titles: [Title]) {
        do {
            let data = try JSONEncoder().encode(titles)
            try data.write(to: fileURL)
        } catch {
            print("Error saving titles: \(error)")
        }
    }

    // Getter for titles
    func getTitles() -> [Title] {
        return titles
    }
}
