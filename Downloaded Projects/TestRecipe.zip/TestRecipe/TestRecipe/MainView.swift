//
//  MainView.swift
//  TestRecipe
//
//  Created by Jackson Schow on 12/13/23.
//

import SwiftUI

struct MainView: View {
    @StateObject var viewModel = TitleViewModel()  // ViewModel instance

    var body: some View {
        NavigationView {
            List {
                // Loop through each title and create a navigation link
                ForEach(viewModel.titles) { title in
                    NavigationLink(destination: TitleView(viewModel: viewModel, title: title)) {
                        Text(title.titleText)  // Display title text
                    }
                }
            }
            .navigationBarTitle("Main Menu")  // Navigation bar title
            // Navigation link for adding a new title
            .navigationBarItems(trailing: NavigationLink("Add New Title", destination: TitleView(viewModel: viewModel, title: Title(titleText: ""))))
        }
    }
}
