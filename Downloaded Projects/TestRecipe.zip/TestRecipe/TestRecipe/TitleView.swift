//
//  TitleView.swift
//  TestRecipe
//
//  Created by Tanner Glazier on 12/13/23.
//

import SwiftUI

struct TitleView: View {
    @ObservedObject var viewModel: TitleViewModel  // ViewModel instance
    @State var title: Title                        // Current title being edited

    var body: some View {
        VStack {
            TextField("Enter Title", text: $title.titleText)  // Text field for title
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            Button("Save") {
                viewModel.saveTitle(title)  // Save the title on button press
            }
            .padding()
        }
    }
}
